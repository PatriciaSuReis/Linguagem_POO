package PROVA;

public class Teste {

	public static void main(String[] args) {
		Gabriel_Patricia obj = new Gabriel_Patricia();
		
		obj.valorRecebido();
		obj.menorMaiorAltura(obj.altura);
		obj.quantadadeM(obj.sexo);
		obj.exibir();
	}
}
